
typedef struct alu {
	int matricula;
  int idade;
} Aluno; 

int mainAluno(Aluno listaAluno[], int qtdAluno);